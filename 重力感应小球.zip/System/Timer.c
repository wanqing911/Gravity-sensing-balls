#include "stm32f10x.h"

/**
 * @brief Timer initialization
 *      ->turn on clock
 *      ->select the clock
 *      ->configure the time base
 * @details frequency = 72M / (PSC + 1) / (ARR + 1)
 * @attention PSC -> 0 ~ 65535
 *            ARR -> 0 ~ 65535
 */
void Timer_Init(void)
{
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);    /*Turn on the timer2 clock*/

    TIM_InternalClockConfig(TIM2);                          /*Select the internal clock*/

    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;      /*configure the time base unit*/
    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;         /*DIV  clock division*/
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;     /*counting mode*/
    TIM_TimeBaseInitStructure.TIM_Period = 500 - 1;                   /*Automatic reloader value(ARR)*/
    TIM_TimeBaseInitStructure.TIM_Prescaler = 720 - 1;                 /*Pridivider value(PSC)*/
    TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;                /*Repeat the counter value(advanced counters)*/
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);

    TIM_ClearFlag(TIM2, TIM_IT_Update);                                 /*Manually clear the interrupt flag bit*/

    TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);                          /*Turn on itconfig*/

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);                     /*NVIC priority grouping*/

    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;           /*preemption priority(抢占优先级)*/
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;                  /*Response priority(响应优先级)*/
    NVIC_Init(&NVIC_InitStructure);

    TIM_Cmd(TIM2, ENABLE);
}


// void TIM2_IRQHandler(void)
// {
//     /*Get the interrupt flag bit*/
//     if(TIM_GetITStatus(TIM2, TIM_IT_Update) == SET)
//     {
//         
//         TIM_ClearFlag(TIM2, TIM_IT_Update);
//     }
// }
