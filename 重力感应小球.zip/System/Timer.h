#ifndef __TIMER_H
#define __TIMER_H

extern int num;
void Timer_Init(void);

#endif
